These java files were designed and programmed by AJIRI OSAUZO JEFFREY (7682469).

To compile and run them with your code on any Unix computer, please make sure that XCode is installed as well as Java 1.6. Then, complete the following steps exactly:

1. Copy and paste your code files and other extras into the directory in which this README.txt file is included.

2. Save the directory in Desktop.

3. Open Terminal app on your Unix system.

4. Go to the stated directory by typing cd Desktop/directoryname and press Enter. (directoryname should be replaced with the name of your directory).

5. Type javac *.java and press Enter.

6. Type java Main and press Enter. (Main should be replaced with your Main class).

7. The program should then run as expected.